import mysql.connector

database = mysql.connector.connect(
    host='your_host',
    user='your_user',
    password='your_password',
    database='your_dbb'
)